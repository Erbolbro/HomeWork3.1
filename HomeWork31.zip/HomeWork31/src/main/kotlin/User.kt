   data class User(
       var username: String = "hello",
       var email: String = "hello@gmail.com",
       var age: Int = 10,
       var password: Int = 12345678,
   ):Verifiable{
       override fun veriable(User: User) {
       if(User==User()){
           println("вход был успешно!")
       } else{
           throw IllegalCallerException("неверные данные для входа ")
       }
       }
   }

