interface Verifiable {
    fun veriable(user:User)
}